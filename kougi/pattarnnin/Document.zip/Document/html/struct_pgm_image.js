var struct_pgm_image =
[
    [ "PgmImage", "struct_pgm_image.html#ac9c9d5d05efb19fea320d72d076c8b10", null ],
    [ "~PgmImage", "struct_pgm_image.html#a9f77a2e321cc3a42e81716194a2fba14", null ],
    [ "height", "struct_pgm_image.html#aeb976059da533f07ae47f145b7629c9d", null ],
    [ "label", "struct_pgm_image.html#a0d7a3966b90b860ddea91af75714e30a", null ],
    [ "pixel", "struct_pgm_image.html#ae63e8334e571611b34dbd95745c5bb3c", null ],
    [ "width", "struct_pgm_image.html#abe55fe80860c5310a00f8eed0bb0bfe9", null ]
];