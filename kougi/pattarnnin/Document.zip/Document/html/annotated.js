var annotated =
[
    [ "PgmImage", "struct_pgm_image.html", "struct_pgm_image" ],
    [ "RecognitionResult", "struct_recognition_result.html", "struct_recognition_result" ]
];