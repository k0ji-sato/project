var _recognition_result_8h =
[
    [ "RecognitionResult", "_recognition_result_8h.html#ad9465053d9c3394ede8d46dbd3eaf2b6", null ],
    [ "RecognitionResultFile", "_recognition_result_8h.html#ab60c7f8a68d677616ffe3d7bcdc134a3", null ]
];