var struct_recognition_result =
[
    [ "RecognitionResult", "struct_recognition_result.html#a1f66f55904538d361a2a92d9353e756c", null ],
    [ "~RecognitionResult", "struct_recognition_result.html#a4434af2372256fb98631a7f6914f4f0c", null ],
    [ "CalcRatio", "struct_recognition_result.html#aa3f49a90caa88c27bb4e26aa0675e848", null ],
    [ "PrintRecognitionResult", "struct_recognition_result.html#a52aaa323657701e37fd83847b76c5b90", null ],
    [ "SaveRecognitionResult", "struct_recognition_result.html#a76ae7a12662977ed3ea48ddfdf2f1f63", null ],
    [ "average_ratio", "struct_recognition_result.html#a4765a2a30d11867a5814266b89ffa0db", null ],
    [ "class_num", "struct_recognition_result.html#a21ecd687a56713e01412a2b52069ee34", null ],
    [ "ratio", "struct_recognition_result.html#aba6c922652bdd1796cc9f802a98c1b39", null ],
    [ "res", "struct_recognition_result.html#a2ef3d654c796836a3dd17137af3ef097", null ]
];