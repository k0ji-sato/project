var _pgm_i_o_8h =
[
    [ "PgmImage", "_pgm_i_o_8h.html#a338d8fcd7a2431f0a7a9b13fce9ad81c", null ],
    [ "LoadPgmImage", "_pgm_i_o_8h.html#ae87577eb01d7d275ab25e98deda6dee0", null ],
    [ "SavePgmImage", "_pgm_i_o_8h.html#ae79698e544cdca21f0a9e37fc6cc15ad", null ]
];