var files =
[
    [ "Step01_ImageIO/Config.h", "_config_8h.html", "_config_8h" ],
    [ "Step01_ImageIO/main.cpp", "_step01___image_i_o_2main_8cpp.html", "_step01___image_i_o_2main_8cpp" ],
    [ "Step01_ImageIO/PgmIO.h", "_pgm_i_o_8h.html", "_pgm_i_o_8h" ],
    [ "Step02_ImageProcessing/main.cpp", "_step02___image_processing_2main_8cpp.html", "_step02___image_processing_2main_8cpp" ],
    [ "Step03_TemplateMatching/main.cpp", "_step03___template_matching_2main_8cpp.html", "_step03___template_matching_2main_8cpp" ],
    [ "Step03_TemplateMatching/RecognitionResult.h", "_recognition_result_8h.html", "_recognition_result_8h" ]
];