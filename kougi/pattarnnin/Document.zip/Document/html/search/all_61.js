var searchData=
[
  ['average_5fratio',['average_ratio',['../struct_recognition_result.html#a4765a2a30d11867a5814266b89ffa0db',1,'RecognitionResult']]]
];
