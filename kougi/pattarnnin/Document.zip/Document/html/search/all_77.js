var searchData=
[
  ['width',['width',['../struct_pgm_image.html#abe55fe80860c5310a00f8eed0bb0bfe9',1,'PgmImage']]]
];
