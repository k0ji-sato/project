var searchData=
[
  ['calcl1distance',['CalcL1Distance',['../_step03___template_matching_2main_8cpp.html#a1f413065e362c47c4b9ffcc503f3748d',1,'main.cpp']]],
  ['calcratio',['CalcRatio',['../struct_recognition_result.html#aa3f49a90caa88c27bb4e26aa0675e848',1,'RecognitionResult']]],
  ['class_5fnum',['class_num',['../struct_recognition_result.html#a21ecd687a56713e01412a2b52069ee34',1,'RecognitionResult']]],
  ['classnum',['ClassNum',['../_config_8h.html#a03e3a82e14e6a02711f5d3647135ee0e',1,'Config.h']]],
  ['config_2eh',['Config.h',['../_config_8h.html',1,'']]]
];
