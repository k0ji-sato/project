var searchData=
[
  ['calcl1distance',['CalcL1Distance',['../_step03___template_matching_2main_8cpp.html#a1f413065e362c47c4b9ffcc503f3748d',1,'main.cpp']]],
  ['calcratio',['CalcRatio',['../struct_recognition_result.html#aa3f49a90caa88c27bb4e26aa0675e848',1,'RecognitionResult']]]
];
