var searchData=
[
  ['testdatafile',['TestDataFile',['../_config_8h.html#a73f5818fb5e21d40a4611b36f6e1d5e3',1,'Config.h']]],
  ['trainingdatafile',['TrainingDataFile',['../_config_8h.html#a4e79c1a2a0cb7dee919dc9fea87c978b',1,'Config.h']]]
];
