var searchData=
[
  ['savepgmimage',['SavePgmImage',['../_pgm_i_o_8h.html#ae79698e544cdca21f0a9e37fc6cc15ad',1,'PgmIO.h']]],
  ['saverecognitionresult',['SaveRecognitionResult',['../struct_recognition_result.html#a76ae7a12662977ed3ea48ddfdf2f1f63',1,'RecognitionResult']]]
];
