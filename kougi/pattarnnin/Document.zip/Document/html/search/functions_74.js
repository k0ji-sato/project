var searchData=
[
  ['templatematching',['TemplateMatching',['../_step03___template_matching_2main_8cpp.html#ac45c23da0fe1862028f88f284636cc35',1,'main.cpp']]]
];
