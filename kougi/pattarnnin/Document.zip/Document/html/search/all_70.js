var searchData=
[
  ['pgmimage',['PgmImage',['../struct_pgm_image.html',1,'PgmImage'],['../struct_pgm_image.html#ac9c9d5d05efb19fea320d72d076c8b10',1,'PgmImage::PgmImage()'],['../_pgm_i_o_8h.html#a338d8fcd7a2431f0a7a9b13fce9ad81c',1,'PgmImage():&#160;PgmIO.h']]],
  ['pgmio_2eh',['PgmIO.h',['../_pgm_i_o_8h.html',1,'']]],
  ['pixel',['pixel',['../struct_pgm_image.html#ae63e8334e571611b34dbd95745c5bb3c',1,'PgmImage']]],
  ['printrecognitionresult',['PrintRecognitionResult',['../struct_recognition_result.html#a52aaa323657701e37fd83847b76c5b90',1,'RecognitionResult']]]
];
