var searchData=
[
  ['testsamplenum',['TestSampleNum',['../_config_8h.html#a569e0ee3c23527c9a6dbae004d4b22e3',1,'Config.h']]],
  ['trainingsamplenum',['TrainingSampleNum',['../_config_8h.html#a001856c5ae81b95b496b306dc3ca387d',1,'Config.h']]]
];
