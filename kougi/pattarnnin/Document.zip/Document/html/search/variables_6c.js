var searchData=
[
  ['label',['label',['../struct_pgm_image.html#a0d7a3966b90b860ddea91af75714e30a',1,'PgmImage']]]
];
