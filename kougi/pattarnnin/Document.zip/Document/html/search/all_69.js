var searchData=
[
  ['imageprocessing',['ImageProcessing',['../_step02___image_processing_2main_8cpp.html#a79bbc6f8a16c28afddb8fcbf3876b4f6',1,'main.cpp']]],
  ['imagesize',['ImageSize',['../_config_8h.html#af3fb33cf4e4928b6a87b0f705c6048fd',1,'Config.h']]]
];
