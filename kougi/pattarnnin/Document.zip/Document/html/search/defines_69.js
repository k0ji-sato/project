var searchData=
[
  ['imagesize',['ImageSize',['../_config_8h.html#af3fb33cf4e4928b6a87b0f705c6048fd',1,'Config.h']]]
];
