var searchData=
[
  ['pixel',['pixel',['../struct_pgm_image.html#ae63e8334e571611b34dbd95745c5bb3c',1,'PgmImage']]]
];
