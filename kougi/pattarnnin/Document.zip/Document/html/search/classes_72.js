var searchData=
[
  ['recognitionresult',['RecognitionResult',['../struct_recognition_result.html',1,'']]]
];
