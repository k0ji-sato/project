var searchData=
[
  ['recognitionresult',['RecognitionResult',['../struct_recognition_result.html#a1f66f55904538d361a2a92d9353e756c',1,'RecognitionResult']]],
  ['returnmatchlabel',['ReturnMatchLabel',['../_step03___template_matching_2main_8cpp.html#a8f6eb83d44f53ad063f1b697c3f430e7',1,'main.cpp']]]
];
