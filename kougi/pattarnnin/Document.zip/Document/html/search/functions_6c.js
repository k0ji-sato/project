var searchData=
[
  ['loadpgmimage',['LoadPgmImage',['../_pgm_i_o_8h.html#ae87577eb01d7d275ab25e98deda6dee0',1,'PgmIO.h']]],
  ['loadtemplateimages',['LoadTemplateImages',['../_step03___template_matching_2main_8cpp.html#ac2f7417069d5f9ba6af7cf88bdee8619',1,'main.cpp']]]
];
