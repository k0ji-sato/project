var searchData=
[
  ['recognitionresult_2eh',['RecognitionResult.h',['../_recognition_result_8h.html',1,'']]]
];
