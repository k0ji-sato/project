var searchData=
[
  ['pgmimage',['PgmImage',['../struct_pgm_image.html#ac9c9d5d05efb19fea320d72d076c8b10',1,'PgmImage']]],
  ['printrecognitionresult',['PrintRecognitionResult',['../struct_recognition_result.html#a52aaa323657701e37fd83847b76c5b90',1,'RecognitionResult']]]
];
