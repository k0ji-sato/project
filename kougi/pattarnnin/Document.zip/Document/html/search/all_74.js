var searchData=
[
  ['templatematching',['TemplateMatching',['../_step03___template_matching_2main_8cpp.html#ac45c23da0fe1862028f88f284636cc35',1,'main.cpp']]],
  ['testdatafile',['TestDataFile',['../_config_8h.html#a73f5818fb5e21d40a4611b36f6e1d5e3',1,'Config.h']]],
  ['testsamplenum',['TestSampleNum',['../_config_8h.html#a569e0ee3c23527c9a6dbae004d4b22e3',1,'Config.h']]],
  ['trainingdatafile',['TrainingDataFile',['../_config_8h.html#a4e79c1a2a0cb7dee919dc9fea87c978b',1,'Config.h']]],
  ['trainingsamplenum',['TrainingSampleNum',['../_config_8h.html#a001856c5ae81b95b496b306dc3ca387d',1,'Config.h']]]
];
