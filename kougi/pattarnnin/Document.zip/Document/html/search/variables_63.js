var searchData=
[
  ['class_5fnum',['class_num',['../struct_recognition_result.html#a21ecd687a56713e01412a2b52069ee34',1,'RecognitionResult']]]
];
