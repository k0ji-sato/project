var searchData=
[
  ['ratio',['ratio',['../struct_recognition_result.html#aba6c922652bdd1796cc9f802a98c1b39',1,'RecognitionResult']]],
  ['recognitionresultfile',['RecognitionResultFile',['../_recognition_result_8h.html#ab60c7f8a68d677616ffe3d7bcdc134a3',1,'RecognitionResult.h']]],
  ['res',['res',['../struct_recognition_result.html#a2ef3d654c796836a3dd17137af3ef097',1,'RecognitionResult']]]
];
