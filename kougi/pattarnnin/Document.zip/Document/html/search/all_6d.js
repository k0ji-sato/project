var searchData=
[
  ['main',['main',['../_step01___image_i_o_2main_8cpp.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main():&#160;main.cpp'],['../_step02___image_processing_2main_8cpp.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main():&#160;main.cpp'],['../_step03___template_matching_2main_8cpp.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main():&#160;main.cpp']]],
  ['main_2ecpp',['main.cpp',['../_step02___image_processing_2main_8cpp.html',1,'']]],
  ['main_2ecpp',['main.cpp',['../_step03___template_matching_2main_8cpp.html',1,'']]],
  ['main_2ecpp',['main.cpp',['../_step01___image_i_o_2main_8cpp.html',1,'']]]
];
