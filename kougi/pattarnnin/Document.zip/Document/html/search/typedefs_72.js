var searchData=
[
  ['recognitionresult',['RecognitionResult',['../_recognition_result_8h.html#ad9465053d9c3394ede8d46dbd3eaf2b6',1,'RecognitionResult.h']]]
];
