var searchData=
[
  ['_7epgmimage',['~PgmImage',['../struct_pgm_image.html#a9f77a2e321cc3a42e81716194a2fba14',1,'PgmImage']]],
  ['_7erecognitionresult',['~RecognitionResult',['../struct_recognition_result.html#a4434af2372256fb98631a7f6914f4f0c',1,'RecognitionResult']]]
];
