var searchData=
[
  ['ratio',['ratio',['../struct_recognition_result.html#aba6c922652bdd1796cc9f802a98c1b39',1,'RecognitionResult']]],
  ['recognitionresult',['RecognitionResult',['../struct_recognition_result.html',1,'RecognitionResult'],['../struct_recognition_result.html#a1f66f55904538d361a2a92d9353e756c',1,'RecognitionResult::RecognitionResult()'],['../_recognition_result_8h.html#ad9465053d9c3394ede8d46dbd3eaf2b6',1,'RecognitionResult():&#160;RecognitionResult.h']]],
  ['recognitionresult_2eh',['RecognitionResult.h',['../_recognition_result_8h.html',1,'']]],
  ['recognitionresultfile',['RecognitionResultFile',['../_recognition_result_8h.html#ab60c7f8a68d677616ffe3d7bcdc134a3',1,'RecognitionResult.h']]],
  ['res',['res',['../struct_recognition_result.html#a2ef3d654c796836a3dd17137af3ef097',1,'RecognitionResult']]],
  ['returnmatchlabel',['ReturnMatchLabel',['../_step03___template_matching_2main_8cpp.html#a8f6eb83d44f53ad063f1b697c3f430e7',1,'main.cpp']]]
];
