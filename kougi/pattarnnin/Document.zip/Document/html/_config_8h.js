var _config_8h =
[
    [ "ClassNum", "_config_8h.html#a03e3a82e14e6a02711f5d3647135ee0e", null ],
    [ "ImageSize", "_config_8h.html#af3fb33cf4e4928b6a87b0f705c6048fd", null ],
    [ "TestSampleNum", "_config_8h.html#a569e0ee3c23527c9a6dbae004d4b22e3", null ],
    [ "TrainingSampleNum", "_config_8h.html#a001856c5ae81b95b496b306dc3ca387d", null ],
    [ "TestDataFile", "_config_8h.html#a73f5818fb5e21d40a4611b36f6e1d5e3", null ],
    [ "TrainingDataFile", "_config_8h.html#a4e79c1a2a0cb7dee919dc9fea87c978b", null ]
];