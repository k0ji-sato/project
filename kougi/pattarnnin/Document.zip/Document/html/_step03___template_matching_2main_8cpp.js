var _step03___template_matching_2main_8cpp =
[
    [ "CalcL1Distance", "_step03___template_matching_2main_8cpp.html#a1f413065e362c47c4b9ffcc503f3748d", null ],
    [ "LoadTemplateImages", "_step03___template_matching_2main_8cpp.html#ac2f7417069d5f9ba6af7cf88bdee8619", null ],
    [ "main", "_step03___template_matching_2main_8cpp.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "ReturnMatchLabel", "_step03___template_matching_2main_8cpp.html#a8f6eb83d44f53ad063f1b697c3f430e7", null ],
    [ "TemplateMatching", "_step03___template_matching_2main_8cpp.html#ac45c23da0fe1862028f88f284636cc35", null ]
];